# KENEYASO GESTION PRO — Version 2.0

Application Android interne séparée de PHARMACOPÉE KENEYASO.

## Fonctions intégrées
- Français + Arabe.
- Admin avec PIN principal.
- Jusqu'à 15 boutiques.
- Jusqu'à 5 vendeurs actifs/enregistrés, chacun avec PIN personnel et boutique attribuée.
- Le vendeur voit seulement sa boutique, son stock et ses propres ventes dans l'interface.
- Jusqu'à 200 produits avec nom, photo, prix, alerte stock faible et quantité par boutique.
- Réception, retrait et transfert de stock avec quantité, note et photo de preuve facultative.
- Nouvelle vente : client, téléphone, adresse, produit, photo officielle, quantité, prix, Payé/Non payé, photo de vente facultative, date/heure et vendeur/boutique automatiques.
- Stock diminué automatiquement après vente.
- Reçu/facture avec photo du produit, partage Android et WhatsApp.
- Statistiques jour / semaine / mois.
- Produits les plus vendus et à faible rotation.
- Ventes par vendeur et par boutique.
- Vendeur modifiable, réaffectable, activable/désactivable sans supprimer son historique.
- Son court + vibration après validation d'une vente.
- Sauvegarde locale : copier, exporter JSON, importer JSON.

## Synchronisation entre téléphones
Le code est prêt pour être relié à une base centrale, mais aucune base Internet n'est incluse dans le ZIP. La réception automatique d'une vente sur le téléphone Admin et la notification Admin à distance nécessitent la connexion à un service en ligne sécurisé (backend / base de données + notifications push).

## Construction APK
Le dépôt GitHub peut conserver le workflow déjà créé. Le ZIP doit rester nommé :
`KENEYASO_GESTION_PRO_SOURCE.zip`

Le projet Android se trouve dans :
`Keneyaso_Gestion_Pro_Android`
