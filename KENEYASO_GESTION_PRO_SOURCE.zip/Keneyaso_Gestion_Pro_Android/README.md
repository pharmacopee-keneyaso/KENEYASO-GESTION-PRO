# KENEYASO GESTION PRO

Application Android séparée pour la gestion commerciale interne de la Pharmacopée.

## Version 1.0
- Français + Arabe
- Accès Admin / Vendeur avec PIN
- Clients et ventes
- Boutiques / vendeurs
- Produits, prix, photo, stock initial et stock restant
- Vente avec photo optionnelle
- Payé / Non payé
- Historique des ventes
- Totaux jour / semaine / mois
- Produits les plus vendus et produits à faible rotation
- Alertes stock faible
- Envoi du récapitulatif de vente au propriétaire via WhatsApp
- Fonctionnement local hors connexion

## Important
La synchronisation automatique entre plusieurs téléphones nécessite un service en ligne (Firebase/Supabase ou serveur). Cette version est prête pour le fonctionnement local et l'envoi WhatsApp. Une connexion cloud peut être ajoutée ensuite sans modifier l'application publique PHARMACOPÉE KENEYASO.

## Build GitHub Actions
Utiliser Java 17, Gradle 9.5.0 et exécuter `gradle assembleDebug` à la racine du projet.
APK: `app/build/outputs/apk/debug/app-debug.apk`
