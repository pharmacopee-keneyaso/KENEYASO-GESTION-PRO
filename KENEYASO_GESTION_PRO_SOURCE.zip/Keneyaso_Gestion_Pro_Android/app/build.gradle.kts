plugins { id("com.android.application") }

android {
    namespace = "com.keneyaso.gestionpro"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.keneyaso.gestionpro"
        minSdk = 24
        targetSdk = 36
        versionCode = 2
        versionName = "2.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }
}

